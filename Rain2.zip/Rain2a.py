"""

SpaceShip2 / Rain 2
This is intended to be similar to SpaceShipAA, but the ship will be positioned
in the middle of the screen and the game world will be scrolled around it 
instead of wrapping.
Stars or some sort of background will need to be introduced to make movement apparent.
And more to come!

Influences:  
Rice Rocks by me made for the Coursera Python Class ( http://www.codeskulptor.org/#user16_BQzpUJrvg8XGhHh.py )
SquirrelEater by Al Sweigart ( http://inventwithpython.com/pygame/chapter8.html )

Credits:
Python! (obviously)
Pygame: http://www.pygame.org/wiki/about  You will need this to run the program!
Pictures/sprites were made by me using Paintbrush  ( http://paintbrush.sourceforge.net/ )

Note to Readers:  
I do not consider this to be written very well, even though it runs.  
Generally: a lot is messy, ad hoc, or kludgey.

"""

__title__ = 'SpaceShip'
__other_title__ = 'Rain'
__version__ = '2a'

__author__ = 'Bob Geis'
__date__ = '2013-06-17'


# 
# Organization: 
# First: imports and global constants
# then: classes
# then: helper functions
# then: the main() function
# then: the call to the main() function if __name__ == '__main__'
#

# import stuff
import random, sys, pygame, math
from pygame.locals import *

# set constants
WINWID = 800				# the size of the game window
WINHEI = 600
HALFWINWID = int(WINWID/2)  # half size of the game window, in case it is important
HALFWINHEI = int(WINHEI/2)
FPS = 30					# frames per second, used in the main game loop FPSCLOCK.tick(FPS) to govern the game speed

# some more constants
ASTRO = 'astro'				# movement like in asteroids
AERO = 'aero'				# movement like an aeroplane
MODE = ASTRO

# rewards
PEOPLE = 'People'
CRYSTAL = 'Crystal'

# more constants
PLAYERSHIP_RADIUS = 22
SHIELD_LIFE = 15
ELASTIC = 5
STAR_DENSITY = 80
ROCK_DENSITY = 60
ROCK_RADIUS = 23
CAPTURABLES_MAX = 6
LITTLECRYSTAL_CHANCE = .3
SPACECRYSTAL_CHANCE = .2
BIGCRYSTAL_CHANCE = .1
POD_CHANCE = .05
LIFEBOAT_CHANCE = .04
AMBULANCE_CHANCE = .03



# colors	   R   G   B
BLACK = 	(  0,  0,  0)
WHITE = 	(255,255,255)
GREY = 		(128,128,128)

RED =   	(255,  0,  0)
GREEN = 	(  0,255,  0)
BLUE =  	(  0,  0,255)

YELLOW = 	(255,255,  0)
MAGENTA = 	(255,  0,255)
CYAN = 		(  0,255,255)

LGREY = 	(150,150,150)
MGREY = 	( 90, 90, 90)
DGREY = 	( 30, 30, 30)

BEAMCOLOR1 = (100,255,255)
BEAMCOLOR2 = (  0,225,225) 
BEAMCOLOR3 = ( 25,175,175)
BEAMCOLOR4 = ( 50,125,125)
BEAMCOLOR5 = ( 25, 25, 25)

# important colors
BGCOLOR = 	BLACK

# load images  			# You might choose to do this in the main() function to allow testing.
# player ship images
STINGRAYMEDIC_IMG = pygame.image.load('StingrayImages/Medic.png')
STINGRAYMEDICTHRUST_IMG = pygame.image.load('StingrayImages/MedicEng.png')
STINGRAYMEDICSHIELD_IMG = pygame.image.load('StingrayImages/MedicFF.png')
STINGRAYMEDICTHRUSTSHIELD_IMG = pygame.image.load('StingrayImages/MedicEngFF.png')
SHIPBOOM_LIST = [pygame.image.load('RockImages/Rock2Boom1.png')]
# star images
STAR_IMG_LIST = [pygame.image.load('StarImages/CyanStar.png'), \
					pygame.image.load('StarImages/BlueStar.png'), \
					pygame.image.load('StarImages/YellowStar.png'), \
					pygame.image.load('StarImages/RedStar.png'), \
					pygame.image.load('StarImages/RedDwarf.png'), \
					pygame.image.load('StarImages/WhiteDwarf.png'), \
					pygame.image.load('StarImages/YellowSun.png'), \
					pygame.image.load('StarImages/RedGiant.png')]

# the starbase
STARBASE1TOP_IMG = pygame.image.load('StarbaseImages/Starbase1Top.png')
STARBASE1TOPFF_IMG = pygame.image.load('StarbaseImages/Starbase1TopAllFF.png')
STARBASE1BOTTOM_IMG = pygame.image.load('StarbaseImages/Starbase1Bottom.png')

# rock images
ROCK_IMG = pygame.image.load('RockImages/Rock2.png')
ROCKBOOM_LIST = [pygame.image.load('RockImages/Rock2Boom1.png'), \
					pygame.image.load('RockImages/Rock2Boom2.png'), \
					pygame.image.load('RockImages/Rock2Boom3.png'), \
					pygame.image.load('RockImages/Rock2Boom4.png'), \
					pygame.image.load('RockImages/Rock2Boom5.png'), \
					pygame.image.load('RockImages/Rock2Boom6.png'), \
					]
					
# capturables images
SPACECRYSTAL_IMG = pygame.image.load('Capturables/SpaceCrystal.png')
LITTLECRYSTAL_IMG = pygame.image.load('Capturables/LittleCrystal.png')
BIGCRYSTAL_IMG = pygame.image.load('Capturables/BigCrystal.png')
ESCAPEPOD_IMG_LIST = [pygame.image.load('EscapepodImages/Red.png'), \
						pygame.image.load('EscapepodImages/RedFF.png'), \
						]
LIFEBOAT_IMG_LIST = [pygame.image.load('LifeboatImages/Red.png'), \
						pygame.image.load('LifeboatImages/RedFF.png'), \
						]
AMBULANCE_IMG_LIST = [pygame.image.load('ShuttleImages/Medic.png'), \
						pygame.image.load('ShuttleImages/MedicFF.png'), \
						]
						
# guide arrow image
ARROW_IMG = pygame.image.load('ArrowImages/Cyan.png')

# classes

# Vessel objects represent ships and things in space!  Including the player's ship.
class Vessel:
	
	def __init__(self, pos, vel, angle, camera, image, thrust_image, shield_image, thrustshield_image):
		self.pos = [pos[0],pos[1]]  	# copies the game coordinates
		self.vel = [vel[0],vel[1]]  	# copies the velocity
		self.angle = angle
		self.angvel = 0
		self.camera = camera			# pointer to the camera coordinates
		self.image = image
		self.thrust_image = thrust_image
		self.shield_image = shield_image
		self.thrustshield_image = thrustshield_image
		self.thrust = False
		self.shield = 0
		self.speed = 0
		self.radius = PLAYERSHIP_RADIUS
		self.people = 0
		self.crystal = 0
		self.shield_strength = 100
		
	# draws the image at the correct orientation
	def draw(self):
		if self.thrust and self.shield:
			self.shield -= 1
			rot_img = pygame.transform.rotate(self.thrustshield_image, self.angle-90)
		elif self.thrust:
			rot_img = pygame.transform.rotate(self.thrust_image, self.angle-90)
		elif self.shield:
			self.shield -= 1
			rot_img = pygame.transform.rotate(self.shield_image, self.angle-90)
		else:
			rot_img = pygame.transform.rotate(self.image, self.angle-90)
		img_size = rot_img.get_size()
		FRAME.blit(rot_img, (self.pos[0] - self.camera[0] - int(img_size[0]/2), \
				 self.pos[1] - self.camera[1] - int(img_size[1]/2)))
		
	# updates the state of the vessel
	def update(self):
		
		# turn off shields if they were on
		
		if MODE == ASTRO:
	
			# movement
			self.pos[0] += int(self.vel[0])
			self.pos[1] += int(self.vel[1])
		
			# rotation
			self.angle += self.angvel
	
			# screen wrapping		# we no longer want wrapping!
			#self.pos[0] = self.pos[0] % WINWID  	
			#self.pos[1] = self.pos[1] % WINHEI
		
			# acceleration
			if self.thrust:
				vec = ang2vec(self.angle)
				self.vel[0] += vec[0] * 5
				self.vel[1] += vec[1] * 5
			
			# friction
			self.vel[0] *= .9
			self.vel[1] *= .9
			
			# just in case
			self.speed = 0
			
		elif MODE == AERO:
			
			# find vel vec
			vec = ang2vec(self.angle)
			self.vel[0] = vec[0] * self.speed
			self.vel[1] = vec[1] * self.speed
		
			# movement
			self.pos[0] += self.vel[0]
			self.pos[1] += self.vel[1]
		
			# rotation
			self.angle += self.angvel
		
			# screen wrapping		# we no longer want wrapping!
			#self.pos[0] = self.pos[0] % WINWID	
			#self.pos[1] = self.pos[1] % WINHEI
			
			# just in case
			self.thrust = False
			
	def center_camera(self):
		self.camera[0] = self.pos[0] - HALFWINWID
		self.camera[1] = self.pos[1] - HALFWINHEI
			
	def turn_left(self):
		# angvel is degrees per frame.  
		# at 30 fps angvel = 9 -> 180 deg / sec
		self.angvel = 9
		
	def turn_right(self):
		# angvel is degrees per frame.  
		# at 30 fps angvel = 9 -> 180 deg / sec
		self.angvel = -9
		
	def turn_stop(self):
		# angvel is degrees per frame.  
		# at 30 fps angvel = 9 -> 180 deg / sec
		self.angvel = 0
		
	def thrust_on(self):
		self.thrust = True
		
	def thrust_off(self):
		self.thrust = False
		
	def forward(self):
		self.speed += 4
			
	def reverse(self):
		self.speed -= 4
		if self.speed < 0:
			self.speed = 0
	
	def group_collide(self,group,obj_radius):
		group_to_remove = set()
		for object in group:
			if dist(self.pos,object.pos) < self.radius + obj_radius:
				group_to_remove.add(object)
				if object.rewardType == PEOPLE:
					self.people += object.rewardAmount
					self.shield = SHIELD_LIFE
				elif object.rewardType == CRYSTAL:
					self.crystal += object.rewardAmount
					self.shield = SHIELD_LIFE
				else:
					self.shield_strength -= 10
					self.shield = int(SHIELD_LIFE/3)
					self.vel[0] += (self.pos[0] - object.pos[0])/ELASTIC
					self.vel[1] += (self.pos[1] - object.pos[1])/ELASTIC
					object.vel[0] -= (self.pos[0] - object.pos[0])/ELASTIC
					object.vel[1] -= (self.pos[1] - object.pos[1])/ELASTIC
		return group_to_remove
		
	def shoot_beam(self):
		BEAMLIST.append(Beam(self.pos, self.angle, self.camera))
		
	def is_destroyed(self):
		if self.shield_strength < 0:
			return True
		

# Beam objects represent laser beams, phaser beams, and similar things
class Beam:
	
	def __init__(self, start, angle, camera):
		
		self.start = start
		self.vec = ang2vec(angle)
		self.range = 500
		self.vec[0] = self.vec[0] * self.range
		self.vec[1] = self.vec[1] * self.range
		self.stop = [self.vec[0] + self.start[0], self.vec[1] + self.start[1]]
		
		self.camera = camera
		
		self.color_list = [BEAMCOLOR1,BEAMCOLOR2,BEAMCOLOR3,BEAMCOLOR4,BEAMCOLOR5]
		self.color = self.color_list[0]
		self.age = 0
		self.lifespan = 8
		self.thickness = 4
		
	def draw(self):
		pygame.draw.line(FRAME, self.color, [self.start[0] - self.camera[0], self.start[1] - self.camera[1]], \
				 [self.stop[0] - self.camera[0], self.stop[1] - self.camera[1]], self.thickness)
		
	def update(self):
		self.age += 1
		self.color = self.color_list[int(self.age/2)]
		self.thickness = int((self.lifespan - self.age)/2)
		if self.age >= self.lifespan:
			BEAMLIST.remove(self)
			
	def hit(self, target, radius):
		vec2tar = [target[0] - self.start[0], target[1] - self.start[1]]
		projection = dot_product(self.vec, vec2tar) / self.range
		if projection < 0 or projection > self.range:
			return False
		elif radius**2 + projection**2 < vec2tar[0]**2 + vec2tar[1]**2:
			return False
		else:
			return True
		
		
# BackGroundObj represent distant objects in the background, like stars.
class BackGroundObj:
	
	def __init__(self, pos, vel, angle, angvel, camera, image, animated = False, image_list=None, step_rate=1, rewardType=None, rewardAmount=None):
		self.pos = [pos[0],pos[1]]		# copies the game coordinates
		self.vel = [vel[0],vel[1]]		# copies the velocity vector
		self.angle = angle
		self.angvel = angvel
		self.camera = camera			# pointer to the camera coordinates
		self.image = image
		self.animated = animated
		self.image_list = image_list
		self.age = 0
		self.step_rate = step_rate
		self.rewardType = rewardType
		self.rewardAmount = rewardAmount
		
	# draws the image at the correct orientation and location
	def draw(self):
		if self.angle == 0:
			rot_img = self.image
		else:
			rot_img = pygame.transform.rotate(self.image, self.angle)
		img_size = rot_img.get_size()
		FRAME.blit(rot_img, (self.pos[0] - self.camera[0] - int(img_size[0]/2), self.pos[1] - self.camera[1]- int(img_size[1]/2)))
		
	def update(self):
		self.pos[0] += self.vel[0]
		self.pos[1] += self.vel[1]
		self.angle += self.angvel
		if self.animated:
			self.age += 1
			self.image = self.image_list[int((self.age / self.step_rate) % len(self.image_list) )]
		
	def outside_active(self):
		if self.pos[0] > 3*WINWID + self.camera[0] or \
				self.pos[0] < -WINWID + self.camera[0] or \
				self.pos[1] > 3*WINHEI + self.camera[1] or \
				self.pos[1] < -WINHEI + self.camera[1]:
			return True
		else:
			return False
			
# Temporary images, like explosions
class TempImage:

	def __init__(self, pos, vel, angle, angvel, camera, image_list, lifespan):
		self.pos = [pos[0],pos[1]]		# copies the game coordinates
		self.vel = [vel[0],vel[1]]		# copies the velocity vector
		self.angle = angle
		self.angvel = angvel
		self.camera = camera			# pointer to the camera coordinates
		self.image_list = image_list 	# list of images to cycle through
		self.lifespan = lifespan
		self.age = 0
		self.image = self.image_list[self.age]	# the current image
		
	# draws the image at the correct orientation and location
	def draw(self):
		if self.angle == 0:
			rot_img = self.image
		else:
			rot_img = pygame.transform.rotate(self.image, self.angle)
		img_size = rot_img.get_size()
		FRAME.blit(rot_img, (self.pos[0] - self.camera[0] - int(img_size[0]/2), self.pos[1] - self.camera[1]- int(img_size[1]/2)))
		
	def update(self):
		self.pos[0] += self.vel[0]
		self.pos[1] += self.vel[1]
		self.angle += self.angvel
		self.age += 1
		if self.age >= self.lifespan:
			BOOMLIST.remove(self)
		else:
			self.image = self.image_list[self.age]


# helper functions

# 2D distance formula
def dist(q, p):
	"""This takes two lists, each contain two numbers representing positions on a 2D grid, and returns the distance between them using the Pythagorean Theorem."""
	return math.sqrt((p[0] - q[0])**2 + (p[1] - q[1])**2)
	
# 2D dot product
def dot_product(p,q):
	"""This takes two lists, each containing two numbers representing vectors, and returns their dot product/scalar product."""
	return p[0]*q[0] + p[1]*q[1]
	
# angle to vector
def ang2vec(angle):
	"""This returns a list of the unit vector at the angle given in degrees."""
	x = math.cos(math.radians(angle))
	y = -math.sin(math.radians(angle))
	return [x,y]
	
# vector to angle
def vec2ang(vector):
	"""This returns an angle in degrees from the x axis given a vector in the form [x,y]"""
	#if vector[0] == 0:
	#	if vector[1] < 0:
	#		return 90
	#	else:
	#		return 180
	angle = math.degrees(math.atan2(vector[0],vector[1]))
	return angle
	
# toggles between ASTRO and AERO flight modes
def toggle_mode():
	global MODE
	if MODE == ASTRO:
		MODE = AERO
	elif MODE == AERO:
		MODE = ASTRO
		
# get a nearby but offscreen spawn point
def get_spawn_pt(camera):
	"""Return [x,y] which are the coordinates of a point offscreen but within one of the eight adjacent screens."""
	x = random.randint(int(-WINWID + camera[0]), int(3*WINWID + camera[0]))
	y = random.randint(int(-WINHEI + camera[1]), int(3*WINHEI + camera[1]))
	while x > camera[0] and x < WINWID + camera[0] and \
			y > camera[1] and y < WINHEI + camera[1]:
		x = random.randint(int(-WINWID + camera[0]), int(3*WINWID + camera[0]))
		y = random.randint(int(-WINHEI + camera[1]), int(3*WINHEI + camera[1]))
	return [x,y]
		
	
# this quits the game and exits python
def terminate():
	"""Quit the game and exit python."""
	pygame.quit()
	sys.exit()	
	
	
	

# the main() function runs the game
def main():  # this part starts the game
	
	global FPSCLOCK, FRAME, BEAMLIST, BOOMLIST
	
	# initialize pygame
	pygame.init()
	FPSCLOCK = pygame.time.Clock()
	FRAME = pygame.display.set_mode((WINWID, WINHEI))
	pygame.display.set_caption('SpaceShip2')
	
	# font
	BASICFONT = pygame.font.Font('freesansbold.ttf', 12)
	
	# start the camera at the origin
	camera = [0,0]
	arrow_ang = 0
	
	# score starts at 0
	people_score = 0
	crystal_score = 0
	gameover = False
	
	# start the player ship in the middle of the screen
	player_ship = Vessel([HALFWINWID,HALFWINHEI],[0,0],0,camera, \
			STINGRAYMEDIC_IMG, STINGRAYMEDICTHRUST_IMG, STINGRAYMEDICSHIELD_IMG, STINGRAYMEDICTHRUSTSHIELD_IMG)
	
	# start with some stars
	star_set = set([])
	for i in range(0,STAR_DENSITY):	
		star_set.add(BackGroundObj([random.randint(-WINWID,3*WINWID),random.randint(-WINHEI,3*WINHEI)],[0,0],0, 0,camera, \
				STAR_IMG_LIST[random.randrange(len(STAR_IMG_LIST)-1)]))
	
	# the starbase
	starbase_top = BackGroundObj([HALFWINWID,HALFWINHEI],[0,0],0, 0,camera, STARBASE1TOP_IMG)
	starbase_bottom = BackGroundObj([HALFWINWID,HALFWINHEI],[0,0],0, 1,camera, STARBASE1BOTTOM_IMG)
	starbase_top_ff = BackGroundObj([HALFWINWID,HALFWINHEI],[0,0],0, 0,camera, STARBASE1TOPFF_IMG)
	starbase_open = 0
	
	# the rocks
	rock_set = set()
	capturables_set = set()
	
	# the beams and booms (explosions)
	BEAMLIST = []
	BOOMLIST = []
	
	
	while True:  # main game loop
	
		
		# handle events
		for event in pygame.event.get():  
			if event.type == QUIT:
				terminate()
			if not gameover:
				if event.type == KEYDOWN:
				 	if event.key == K_LEFT or event.key == K_a:
					 	player_ship.turn_left()
				 	elif event.key == K_RIGHT or event.key == K_d:
					 	player_ship.turn_right()
			 		elif event.key == K_UP or event.key == K_w:
				 		player_ship.thrust_on()
				 		player_ship.forward()
				 	elif event.key == K_DOWN or event.key == K_s:
					 	player_ship.reverse()
				 	elif event.key == K_SPACE:
					 	player_ship.shoot_beam()
			 		elif event.key == K_t:
				 		toggle_mode()
				elif event.type == KEYUP:
				 	if event.key == K_LEFT or event.key == K_a:
					 	player_ship.turn_stop()
				 	elif event.key == K_RIGHT or event.key == K_d:
					 	player_ship.turn_stop()
			 		elif event.key == K_UP or event.key == K_w:
				 		player_ship.thrust_off()
				 	
		# update game state
		
		# update the player ships
		if not gameover:
			player_ship.update()
			player_ship.center_camera()
			player_ship.group_collide(rock_set, ROCK_RADIUS)
			captured = player_ship.group_collide(capturables_set, 1)
			capturables_set.difference_update(captured)
			if dist(player_ship.pos, starbase_top.pos) < 50:
				people_score += player_ship.people
				crystal_score += player_ship.crystal
				player_ship.people = 0
				player_ship.crystal = 0
				player_ship.shield = 5
				player_ship.shield_strength = 100
				starbase_open = 5
			gameover = player_ship.is_destroyed()
			if gameover:
				BOOMLIST.append(TempImage(player_ship.pos,player_ship.vel,player_ship.angle,player_ship.angvel, \
							camera, ROCKBOOM_LIST, len(ROCKBOOM_LIST)))
				for i in range(0,5):
					if random.random() < .9:
						capturables_set.add(BackGroundObj(player_ship.pos, \
								[random.randint(-5,6),random.randint(-2,3)], \
								0, random.randint(-5,6),camera,ESCAPEPOD_IMG_LIST[0], \
								True, ESCAPEPOD_IMG_LIST, SHIELD_LIFE, PEOPLE, \
								random.randrange(1,6)))
					if random.random() < .5:
						capturables_set.add(BackGroundObj(player_ship.pos, \
								[random.randint(-4,5),random.randint(-2,3)], \
								0, random.randint(-5,6),camera,LIFEBOAT_IMG_LIST[0], \
								True, LIFEBOAT_IMG_LIST, SHIELD_LIFE, PEOPLE, \
								random.randrange(5,11)))
					if random.random() < .2:
						capturables_set.add(BackGroundObj(player_ship.pos, \
								[random.randint(-3,4),random.randint(-2,3)], \
								0, random.randint(-5,6),camera,AMBULANCE_IMG_LIST[0], \
								True, AMBULANCE_IMG_LIST, SHIELD_LIFE, PEOPLE, \
								random.randrange(10,21)))
		
		# beams and booms
		for beam in BEAMLIST:
			beam.update()
		for boom in BOOMLIST:
			boom.update()
		
		# the starbase 
		starbase_top.update()
		starbase_bottom.update()
		arrow_angle = vec2ang([player_ship.pos[0] - starbase_top.pos[0], \
				player_ship.pos[1] - starbase_top.pos[1]])
		
		# update stars and remove those that are out of range
		star_copy = set(star_set)
		for star in star_copy:
			star.update()
			if star.outside_active():
				star_set.remove(star)
				
		# add new stars as needed
		while len(star_set) < STAR_DENSITY:
			star_set.add(BackGroundObj(get_spawn_pt(camera),[0,0],0,0,camera, \
					STAR_IMG_LIST[random.randrange(len(STAR_IMG_LIST))]))
			
		# now we do for rocks what we did for stars
		# update rocks and remove those that are out of range
		rock_copy = set(rock_set)
		for rock in rock_copy:
			rock.update()
			if rock.outside_active():
				rock_set.remove(rock)
			for beam in BEAMLIST:
				if beam.hit(rock.pos, ROCK_RADIUS):
					BOOMLIST.append(TempImage(rock.pos,rock.vel,rock.angle,rock.angvel, \
							camera, ROCKBOOM_LIST, len(ROCKBOOM_LIST)))
					if random.random() < LITTLECRYSTAL_CHANCE:
						capturables_set.add(BackGroundObj(rock.pos,rock.vel,rock.angle,rock.angvel*3, \
								camera,LITTLECRYSTAL_IMG, False, None, 1, CRYSTAL, \
								random.randrange(1,6)))
					elif random.random() < SPACECRYSTAL_CHANCE:
						capturables_set.add(BackGroundObj(rock.pos,rock.vel,rock.angle,rock.angvel*3, \
								camera,SPACECRYSTAL_IMG, False, None, 1, CRYSTAL, \
								random.randrange(5,11)))
					elif random.random() < BIGCRYSTAL_CHANCE:
						capturables_set.add(BackGroundObj(rock.pos,rock.vel,rock.angle,rock.angvel*3, \
								camera,BIGCRYSTAL_IMG, False, None, 1, CRYSTAL, \
								random.randrange(10,21)))
					rock_set.remove(rock)
					
		
		# add new rocks as needed
		while len(rock_set) < ROCK_DENSITY:
			rock_set.add(BackGroundObj(get_spawn_pt(camera), \
					[random.randint(-3,4),random.randint(-3,4)], \
					0, random.randint(-10,11),camera,ROCK_IMG))
					
		# update and remove capturables
		capturables_copy = set(capturables_set)
		for capturable in capturables_copy:
			capturable.update()
			if capturable.outside_active():
				capturables_set.remove(capturable)
				
		# add new capturables
		if len(capturables_set) < CAPTURABLES_MAX:
			if random.random() < POD_CHANCE:
				capturables_set.add(BackGroundObj(get_spawn_pt(camera), \
						[random.randint(-2,3),random.randint(-2,3)], \
						0, random.randint(-5,6),camera,ESCAPEPOD_IMG_LIST[0], \
						True, ESCAPEPOD_IMG_LIST, SHIELD_LIFE, PEOPLE, \
						random.randrange(1,6)))
			elif random.random() < LIFEBOAT_CHANCE:
				capturables_set.add(BackGroundObj(get_spawn_pt(camera), \
						[random.randint(-2,3),random.randint(-2,3)], \
						0, random.randint(-5,6),camera,LIFEBOAT_IMG_LIST[0], \
						True, LIFEBOAT_IMG_LIST, SHIELD_LIFE, PEOPLE, \
						random.randrange(5,11)))
			elif random.random() < AMBULANCE_CHANCE:
				capturables_set.add(BackGroundObj(get_spawn_pt(camera), \
						[random.randint(-2,3),random.randint(-2,3)], \
						0, random.randint(-5,6),camera,AMBULANCE_IMG_LIST[0], \
						True, AMBULANCE_IMG_LIST, SHIELD_LIFE, PEOPLE, \
						random.randrange(10,21)))
				 	
		
		# drawing queue
		# remember to draw background first and player last (later things are drawn over earlier things)
		
		FRAME.fill(BGCOLOR)
		
		for star in star_set:
			star.draw()
			
		for beam in BEAMLIST:
			beam.draw()
			
		for boom in BOOMLIST:
			boom.draw()
			
		for rock in rock_set:
			rock.draw()
			
		for capturable in capturables_set:
			capturable.draw()
			
		starbase_bottom.draw()
		if starbase_open:
			starbase_open -= 1
			starbase_top_ff.draw()
		else:
			starbase_top.draw()
		
		if not gameover:
			player_ship.draw()
		
		# draw guide arrow
		rot_arrow_img = pygame.transform.rotate(ARROW_IMG, arrow_angle)
		arrow_img_size = rot_arrow_img.get_size()
		FRAME.blit(rot_arrow_img, [20 - arrow_img_size[0], WINHEI - 30 - arrow_img_size[1]])
		
		# draw text
		station_text = BASICFONT.render('People Rescued: '+str(people_score)+ \
				'   Crystal Refined: '+str(crystal_score), True, WHITE)
		ship_text = BASICFONT.render('Shield Strength: '+str(player_ship.shield_strength)+ \
				'   People Onboard: '+str(player_ship.people)+ \
				'   Crystal Onboard: '+str(player_ship.crystal), True, WHITE)
				
		#text_rect = text_surf.get_rect()
		FRAME.blit(station_text, [0,WINHEI-12])
		FRAME.blit(ship_text, [0,0])
        		
		# draw and tick!
		pygame.display.update()
		FPSCLOCK.tick(FPS)
				
	
# this calls main() only if the script is run, and not if it is being imported elsewhere (like for testing)
if __name__ == '__main__':
	main()